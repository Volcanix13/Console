import os
import shutil
import subprocess
import platform
import socket

# ===================== UTILITAIRES =====================
def create_item(name):
    if '.' in name:
        with open(name, 'w') as f:
            f.write('')
        return f"Fichier '{name}' créé."
    else:
        os.makedirs(name, exist_ok=True)
        return f"Dossier '{name}' créé."

def delete_item(name):
    if os.path.isfile(name):
        os.remove(name)
        return f"Fichier '{name}' supprimé."
    elif os.path.isdir(name):
        shutil.rmtree(name)
        return f"Dossier '{name}' supprimé."
    else:
        return f"'{name}' n'existe pas."

def move_item(src, dst):
    if os.path.exists(src):
        shutil.move(src, dst)
        return f"'{src}' déplacé vers '{dst}'."
    else:
        return f"'{src}' n'existe pas."

def copy_item(src, dst):
    if os.path.isfile(src):
        shutil.copy2(src, dst)
        return f"Fichier '{src}' copié vers '{dst}'."
    elif os.path.isdir(src):
        shutil.copytree(src, dst)
        return f"Dossier '{src}' copié vers '{dst}'."
    else:
        return f"'{src}' n'existe pas."

def find_file(name, path='.'):
    results = []
    for root, dirs, files in os.walk(path):
        if name in files:
            results.append(os.path.join(root, name))
    if results:
        return "\n".join(results)
    else:
        return f"'{name}' introuvable."

# ===================== COMMANDES CMD =====================
def cmd_cd(path=None):
    if path:
        try:
            os.chdir(path)
            return f"Dossier courant : {os.getcwd()}"
        except FileNotFoundError:
            return f"Le dossier '{path}' n'existe pas."
    return os.getcwd()

def cmd_dir():
    return "\n".join(os.listdir(os.getcwd()))

def cmd_cls():
    os.system('cls' if os.name == 'nt' else 'clear')

def cmd_echo(text):
    return text

def cmd_mkdir(name):
    os.makedirs(name, exist_ok=True)
    return f"Dossier '{name}' créé."

def cmd_rmdir(name):
    if os.path.isdir(name):
        shutil.rmtree(name)
        return f"Dossier '{name}' supprimé."
    return f"'{name}' n'existe pas."

def cmd_del(name):
    if os.path.isfile(name):
        os.remove(name)
        return f"Fichier '{name}' supprimé."
    return f"'{name}' n'existe pas."

def cmd_ren(old, new):
    if os.path.exists(old):
        os.rename(old, new)
        return f"'{old}' renommé en '{new}'."
    return f"'{old}' n'existe pas."

def cmd_ping(host):
    return os.system(f"ping {host}")

def cmd_ipconfig():
    return os.popen("ipconfig" if os.name == 'nt' else "ifconfig").read()

def cmd_systeminfo():
    return os.popen("systeminfo" if os.name == 'nt' else "uname -a").read()

def cmd_tasklist():
    return os.popen("tasklist" if os.name == 'nt' else "ps aux").read()

def cmd_ver():
    return platform.platform()

# ===================== RACCOURCIS WINDOWS =====================
def show_windows_shortcuts():
    shortcuts = """
Raccourcis clavier Windows :
- Win + E : Ouvrir l’explorateur de fichiers
- Win + D : Afficher le bureau
- Win + Tab : Vue des tâches
- Win + L : Verrouiller l’ordinateur
- Win + I : Paramètres
- Win + R : Exécuter
- Win + S : Rechercher
- Win + Maj + S : Capture d’écran
- Win + V : Presse-papier
- Win + +/- : Loupe
- Win + flèche gauche/droite : Ancrer la fenêtre
- Win + Maj + flèche haut/bas : Redimensionner fenêtre
- Win + G : Xbox Game Bar
"""
    return shortcuts

# ===================== CONSOLE =====================
def help_command():
    return """
Commandes disponibles:
- help : afficher cette aide
- clear : nettoyer l'écran
- exit : fermer la console
- open [programme] : ouvrir un programme
- create/delete/move/copy/find : gestion fichiers/dossiers
- cd [dossier] : changer de dossier
- dir : lister le contenu du dossier
- echo [texte] : afficher un texte
- mkdir [nom] : créer un dossier
- rmdir [nom] : supprimer un dossier
- del [nom] : supprimer un fichier
- ren [ancien] [nouveau] : renommer fichier/dossier
- ping [hôte] : tester la connexion
- ipconfig : afficher la config réseau
- systeminfo : infos système
- tasklist : lister programmes actifs
- ver : version de Windows
- winshortcuts : afficher raccourcis clavier Windows
"""

def main():
    print("=== Bienvenue dans MyFastConsole ===")
    print("Tapez 'help' pour voir les commandes.\n")
    
    while True:
        try:
            command_input = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nFermeture de la console.")
            break

        if not command_input:
            continue

        parts = command_input.split()
        cmd = parts[0]
        args = parts[1:]

        if cmd == "help":
            print(help_command())
        elif cmd in ["clear", "cls"]:
            cmd_cls()
        elif cmd == "exit":
            break
        elif cmd == "open" and args:
            try:
                subprocess.Popen(args[0])
                print(f"Programme '{args[0]}' ouvert.")
            except Exception as e:
                print(f"Erreur : {e}")
        elif cmd == "create" and args:
            print(create_item(args[0]))
        elif cmd == "delete" and args:
            print(delete_item(args[0]))
        elif cmd == "move" and len(args) == 2:
            print(move_item(args[0], args[1]))
        elif cmd == "copy" and len(args) == 2:
            print(copy_item(args[0], args[1]))
        elif cmd == "find" and args:
            print(find_file(args[0]))
        elif cmd == "cd":
            print(cmd_cd(args[0]) if args else cmd_cd())
        elif cmd == "dir":
            print(cmd_dir())
        elif cmd == "echo" and args:
            print(cmd_echo(" ".join(args)))
        elif cmd == "mkdir" and args:
            print(cmd_mkdir(args[0]))
        elif cmd == "rmdir" and args:
            print(cmd_rmdir(args[0]))
        elif cmd == "del" and args:
            print(cmd_del(args[0]))
        elif cmd == "ren" and len(args) == 2:
            print(cmd_ren(args[0], args[1]))
        elif cmd == "ping" and args:
            cmd_ping(args[0])
        elif cmd == "ipconfig":
            print(cmd_ipconfig())
        elif cmd == "systeminfo":
            print(cmd_systeminfo())
        elif cmd == "tasklist":
            print(cmd_tasklist())
        elif cmd == "ver":
            print(cmd_ver())
        elif cmd == "winshortcuts":
            print(show_windows_shortcuts())
        else:
            print(f"Commande inconnue : '{cmd}'")

if __name__ == "__main__":
    main()
